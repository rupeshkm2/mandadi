'use strict';

/*
document.querySelector('.message'); // here selector  .message is an .html element (you can check .html file )
// document is js object and queryselector is methods in it 
// since it is a class we refer as .message , it its an id the we shouls call as #message

//console.log(document.querySelector('.message'));
console.log(document.querySelector('.message').textContent); 

// dom : document object model , dom allows to use js to manipulate html/css
//dom is an connection point b/w html and js code 
// dom is automatically created when html page load 

// document is an special object and it is an entry point to the DOM 
// dom!= java script 

// set content 
document.querySelector('.message').textContent='Correct Number!';

// read after updating the content , this is DOM manipulation 
console.log(document.querySelector('.message').textContent); 

// below .number is call is for sybmol (?) and .socre is for number (20) , check .html files if any questions 

// again DOM manipulation below classes 
document.querySelector('.number').textContent=13;
document.querySelector('.score').textContent=10;



//document.querySelector('.guess').value;

//console.log(document.querySelector('.guess').value);

document.querySelector('.guess').value=23;
console.log(document.querySelector('.guess').value);

*/

// handling click event 
// event listner : we can wait certain event to heppan and react to it
// we are doing here is when click on check button then log the value into console 

const secretNumber=Math.trunc(Math.random()*20)+1;
let score=20;
let highScore=0;
// create function to avoid duplicate below to call DOM object 
const displayMessage=function(message){
    document.querySelector('.message').textContent=message;
}

//document.querySelector('.number').textContent=secretNumber;
document.querySelector('.check').addEventListener('click',function(){
    //console.log(document.querySelector('.guess').value);
    const guess=Number(document.querySelector('.guess').value);
  //  console.log(guess);
    console.log(typeof guess);

    //  if(!guess) :when no number/input is entered/guess variable 
    if(!guess){
        console.log('No Number');

    }
    // when player win 
    else if(guess===secretNumber) {
      //  document.querySelector('.message').textContent='Correct Number!';
      displayMessage('Correct Number!');
        document.querySelector('.number').textContent=secretNumber;
    // DOM on CSS 
    // change page body color whne guess is correct 

    document.querySelector('body').style.backgroundColor='#60b347';
    // increate yhe size of number when guess is correct 
    document.querySelector('.number').style.width='30rem'
    // below logic is to impliment high score 
     if (score>highScore)
     {
         highScore=score;
         document.querySelector('.highscore').textContent=highScore;
     }

      // when guess is wrong ( code refactor ) and commented below previous logic 
    } else if(guess!=secretNumber){
        if(score>1)
        {

        //document.querySelector('.message').textContent=guess>secretNumber?  'Too High!': 'Too Low';
        displayMessage(guess>secretNumber?  'Too High!': 'Too Low')
        // decrease score value when wrong entry 
        score=score-1;
        //score--; // another way to do
        document.querySelector('.score').textContent=score;
        }else 
        {
            //document.querySelector('.message').textContent='you lost the game ';
            displayMessage('you lost the game');
            document.querySelector('.score').textContent=0;

        }
    }
    /*
      // whem guess is too high 
    else if(guess>secretNumber){

        if(score>1)
        {

        document.querySelector('.message').textContent='Too High!';

        // decrease score value when wrong entry 
        score=score-1;
        //score--; // another way to do
        document.querySelector('.score').textContent=score;
        }else 
        {
            document.querySelector('.message').textContent='you lost the game ';
            document.querySelector('.score').textContent=0;

        }
        // when guess is too low 
    }else if(guess<secretNumber){

        if(score>1)
        {
        document.querySelector('.message').textContent='Too Low!';
        // decrease score value when wrong entry 
        score=score-1;
        //score--; // another way to do
        document.querySelector('.score').textContent=score;
        }
        else 
        {
            document.querySelector('.message').textContent='you lost the game ';
            document.querySelector('.score').textContent=0;
        }
    }
*/
});
//  <button class="btn check">Check!</button>  , there are teo classes btn and again 
// here btn is for (again!) and check is for button (check ) , since we are working on check button we that perticular calss only 

// addEventListener method take two parameters 
// first is action ,second is what shouls happen when action performed 
// we created function to print the value when click on check button 




// create an event handler when click on Again! button evrty thing shouls be reset to original 


document.querySelector('.again').addEventListener('click',function(){
   document.querySelector('.score').textContent=20;
  // document.querySelector('.message').textContent='Strat Guessing... ';
   displayMessage('Strat Guessing... ')
   document.querySelector('.number').textContent='?';
   document.querySelector('.guess').textContent='';
   document.querySelector('body').style.backgroundColor='#222';
   document.querySelector('.number').style.width='15rem'

   console.log('inside again button');

})












