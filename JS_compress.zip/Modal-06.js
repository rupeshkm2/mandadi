'use strict';
// here are giving vriable names same as calss names just for better understanding in furtger code , dont confuse 
const modal=document.querySelector('.modal');
const overlay=document.querySelector('.overlay');
const btnCloseModal= document.querySelector('.close-modal');
//const btnOpenModal=document.querySelector('.show-modal');

//console.log(btnOpenModal);
// so when we use querySelector and the class name same for multiple buttons it will select/show only first one 
// example is above class '.show-modal'
// to select all we need to use querySelectorAll

const btnOpenModal=document.querySelectorAll('.show-modal');

//console.log(btnOpenModal);


for (let i=0;i<btnOpenModal.length;i++)
{
    //console.log(btnOpenModal[i].textContent);
    btnOpenModal[i].addEventListener('click',function(){
        console.log('button clicked ');
      // modal is the variable from above(.model) class and callslist the js methos  
      // here we saying remove hidden (currently the text is hidden (class="modal hidden")when click event  
      // no need to use . here like .hidden in this remove function 
      // . is only for selector (querySelector/querySelectorAll etc )
       modal.classList.remove('hidden');
       overlay.classList.remove('hidden');

    });

}

const closeModal=function(){
    // this is to when click on X (close) button/ click on overlay  
    //put the  popo up again  into hidden 
    modal.classList.add('hidden');
    overlay.classList.add('hidden');
}

// applying the above function here when X button clicked 
btnCloseModal.addEventListener('click',closeModal)

/*
overlay.addEventListener('click',function(){
    modal.classList.add('hidden');
    overlay.classList.add('hidden');


})
*/

// applying the above function here when click on overlay 
overlay.addEventListener('click',closeModal);

// key press event which are keyboard events ( whhen click ESC escape button)

// keydown is when we press any key it will trigger 
// we are passing parameter to the function to log the event , which mean which is pressed 
// for ex if we press letter R it will capture the key (kere key mean lettrt R)
// so this we can impliment when click on esc button again we can put back the test to hidden 
// we can use any input argumenet name i used here as (evenInput) for better readability
// you can check by enabling console.log to see which key was entered ex : key: "Escape" /key: "n" ( when we press n)
document.addEventListener('keydown',function(evenInput){
    console.log('kay press ');
    console.log(evenInput);
    if(evenInput.key==='Escape' && !modal.classList.contains('hidden'))
// console.log('escape was pressed ');
// no nned to hidden every time when click on esc 
// exaple in jeneral we may click esc button for other reason , so don't want to call this every time when click on esc
// so call only when class is not hidden 
  
   closeModal();// hide the  modal and overlay 

})



