'use strict';


// first we are resetting values to 0 (zero)

// when we slect by ID we need use # 
const score0El=document.querySelector('#score--0');
const score1El=document.getElementById('score--1'); // another way to select ID , since it already know its and ID so no need to use #
const diceEl=document.querySelector('.dice');
const current0El=document.getElementById('current--0');
const current1El=document.getElementById('current--1');
const player0El=document.querySelector('.player--0');
const player1El=document.querySelector('.player--1');


score0El.textContent=0;
score1El.textContent=0;
diceEl.classList.add('hidden'); // hidden the dice 


// rolling the dice 

const btnNew=document.querySelector('.btn--new');
const btnRoll=document.querySelector('.btn--roll');
const btnHold=document.querySelector('.btn--hold');
 let currentScore=0;
 let activePlayer=0;
 let  scores=[0,0];// because two players we declated arrau with two initializing with 0 
 let playing=true;

const switchPlayer=function(){
    document.getElementById(`current--${activePlayer}`).textContent=0; // before swithcing to next payer , set current player score to zero 
          currentScore=0;
          activePlayer=activePlayer===0?1:0;
          player0El.classList.toggle('player--active')   //  toggle is add class when not there , and remove when its is there 
          player1El.classList.toggle('player--active')    
}


btnRoll.addEventListener('click',function(){
    // 1.generating randon dice roll
    if (playing) {
    let dice =Math.trunc( Math.random()*6)+1;

    // 2.display dice 
  
    diceEl.classList.remove('hidden'); // remove hidden when click
    // we need to show the dice image based on random number (dice)

    diceEl.src=`dice-${dice}.png`; // settign the image dynamically same as html (<img src="dice-5.png" alt="Playing dice" class="dice" />)



    // 3.check for rolled 1 , if its true swithc to next player 
    
      if(dice!==1){
          // add dice to the current score 
          currentScore=currentScore+dice;
          document.getElementById(`current--${activePlayer}`).textContent=currentScore;

      }else {

        switchPlayer();

        /*
          // switch to next player 
          document.getElementById(`current--${activePlayer}`).textContent=0; // before swithcing to next payer , set current player score to zero 
          currentScore=0;
          activePlayer=activePlayer===0?1:0;
          player0El.classList.toggle('player--active')   //  toggle is add class when not there , and remove when its is there 
          player1El.classList.toggle('player--active')           
            // above  is when when player 1 active then remove else add 
            // if plater 2 is active then remove elase add  , at all time only one player should be active 
         */
      }
    }
})


btnHold.addEventListener('click',function(){
    if(playing){
  //1 add current score to score of the active playe's score 
  scores[activePlayer]+=currentScore;
  document.getElementById(`score--${activePlayer}`).textContent=scores[activePlayer];

  //2. cehck score if it's >=20
 
    
  if (scores[activePlayer]>=20)
     {
             // finish the game 
             playing=false;
             document.querySelector(`.player--${activePlayer}`).classList.add('player--winner');
             document.querySelector(`.player--${activePlayer}`).classList.remove('player--active');
             diceEl.classList.add('hidden');



     }else{
        switchPlayer();
     }
   
 }
  // if not swith the next player 
})

// when click on new game , need to reset everything 
btnNew.addEventListener('click',function(){
    document.getElementById(`current--0`).textContent=0; // another way is  current0El.textContent=0;
    document.getElementById(`current--1`).textContent=0;
    document.getElementById(`score--0`).textContent=0;
    document.getElementById(`score--1`).textContent=0;
    document.querySelector(`.player--0`).classList.add('player--active');
    document.querySelector(`.player--1`).classList.remove('player--active');
    diceEl.classList.add('hidden');
    player0El.classList.remove('player--winner') // this is to remove the color when any player wins the game 
    player1El.classList.remove('player--winner')

     currentScore=0;
     activePlayer=0;
     scores=[0,0];
     playing=true;


  // we can create a function instead repeting the above variable assignment twice once at above and here at second time 









})