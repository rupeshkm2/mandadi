'use strict';


/*
function calAge(birthyear){
    const age=2022-birthyear;
    //console.log(firstName); //we can access this firstNmme variable because it declared as  global scope 
    function printAge(){
        let output=`${firstName} you are ${age}, born in ${birthyear}`;
        console.log(output);

      if(birthyear>=1981 && birthyear<=1996)
      {
        var millenial=true;  // it is function scope not block scope scice we declare as VAR 
        const firstName='kumar';
          const str=`Oh, and you're a millenial, ${firstName}`;
          console.log(str);

          function add(a,b){ // the scope of this function is to this block 
              return a+b; 
          }
          output='NEW OUTPUT' ; // replace the value of outerscopr varialbe in inside 
      }

        //console.log(str);// here str is not in scop , ot is block sope 
        console.log(millenial); // we can access this millenial , thought it is block scope 
        // when we declare varibale with var , it considered as function scope here , so it can be accessed through out function 

       // add(2,3); // we can't access this function outaside the block , since it declared inside the block 
       // this is true only for srtict mode .

       console.log(output);// now you will see the result of replaced value 

    }

    printAge();
    return age;
};



const firstName='rupesh'
calAge(1987);
//console.log(age);// not accessable becaus of  age not in scope here 

//printAge();//not accessable becaus of  printAge  not in scope here 



//----------------------------class 95 -------------------------------------
// hosting and TDZ is practice 

console.log(me);
//console.log(job);  // temporal dead zone 
//console.log(year);  // temporal dead zone 

var me ='rupesh';
let job='developer';
const year =1987;






console.log(addDecl(2,3));  // able to function declation before declation 

//console.log(addExpr(2,3)); // can't access  before declaration, because addExpr is const variable so it is in temp dead zone 

//console.log(addArrow(2,3)); // can't access beore declaration 

// function declation  


function addDecl(a,b){
    return a+b;
}

// function expression  
const addExpr=function(a,b){
    return a+b;
} 

// arrow  expression  

var addArrow=(a,b)=>a+b;


// example 

if(!numProducts) // the false condition is when numProducts =0 
deleteShoppingCart();
// since we declated numProducts as var , in above if condtion the value is undefined since we called before declation 
// and executed the function , so it is danger to use VAR in some situation 
// based on above we removed all the products 
// here undefined considered and false 

var numProducts=10;
function deleteShoppingCart(){
    console.log('all products deleted ');
}


var x=1;
let y=2;
const z=3;

// window is js objects 
console.log(x===window.x);
console.log(x===window.y);
console.log(x===window.z);



//---------------------------class 96 ------------------------------------

// this keyword 

// the value is only assigned oly when the function is called 
// the value is point to owner of the function 
// this = object that calling the method 


//-------------------------------class 97-----------------------------------

console.log(this);

const calAge=function(birthyear){
    console.log(2022-birthyear);
    console.log(this);
}



calAge(1987); // we are strict mode so  THIS  is undefined 



const calAgeArrow=(birthyear)=>{
    console.log(2022-birthyear);
    console.log(this);
}

calAgeArrow(1987); // yarrow function doesn't het their own THIS keyword
// it used parent scope (window)



const jonas ={
    year:1987,
    calAge: function(){
        console.log(this);
        console.log(2022-this.year);;

    }
}

jonas.calAge();// we can refer here 



const matilda ={
    year :2017
}

// here we barrowd/copied  the methis calAge from jonas to matilda
matilda.calAge=jonas.calAge


console.log(matilda);


matilda.calAge();


const f=jonas.calAge;
console.log(f);
//  f();// this will fail 




//-----------------------class 98 ---------------------------------------------



const jonas ={
    firstName: 'jonas',
    year:1987,
    calAge: function(){
        console.log(this);
        console.log(2022-this.year);

        const isMIllenial=function(){
            console.log(this.year>=1981 && this.year<=1996);
        };

       isMIllenial();// regukar function inside a methid  with THIS keyword gives error (undefined )
    },

    greet: ()=> console.log(`hey ${this.firstName}`)
}



jonas.greet(); // arrow function doesn't get it with this keywork 
// the arrow function will get the parent scope and here above the function is declared as global so this keyword not able inherit fron jonas object 

console.log(this.firstName);// undefined

// because of this we should not use arrow function as a method 

//jonas.calAge(); // 



// calling a regukar function inside a methid with THIS keyworrd in must be undefined 
// that is why we got undefined   'year ' error with above stmt onas.calAge();


//  one of the work around is assign the THIS keyword value to variable just above the function 

const jonas1 ={
    firstName: 'jonas',
    year:1987,

    calAge1: function(){
        console.log(this);
        console.log(2022-this.year);
        const self=this; // assigning the this value to self and refer below with self 
        const isMIllenial1=function(){
            console.log(self.year>=1981 && self.year<=1996);
        };

       isMIllenial1();// regukar function inside a methid  with THIS keyword gives error (undefined )
    },

    greet1: ()=> console.log(`hey ${this.firstName}`)
}

jonas1.calAge1(); // 


// another solution with ES6 is with arrow function 






const jonas2 ={
    firstName: 'jonas',
    year:1987,

    calAge2: function(){
        console.log(this);
        console.log(2022-this.year);
        const isMIllenial2=()=>{
            console.log(this.year>=1981 && this.year<=1996);
        };

       isMIllenial2();
    },

    greet2: ()=> console.log(`hey ${this.firstName}`)
}

jonas2.calAge2();

// this is worked because arrow function used parent scope (jonas2)


// arguments keywork 
// this is avoalbe only in regular function 

const addExpr=function(a,b){
    console.log(arguments);
    return a+b;

}

addExpr(2,5);
addExpr(2,5,6,12,14);

// this arguments availeb only is function expression and function declation 
//but not in arrow function 




const addArrow=(a,b)=>{
    console.log(arguments);
    return a+b;
}


//addArrow(2,3); // fail with argument undefined 





//-----------------------class 99 ----------------------------------

let age =30;
let oldAge=age;
age=31;

console.log(age);
console.log(oldAge);



const me ={
    name:'jonas',
    age:30
};


const friend=me; // creating/copying  neew object with another 
console.log(me);
console.log(friend);
console.log('----after assigning --------');
friend.age=27;
console.log(me);
console.log(friend);


// note : it's a misconception that all athe variables that declared as cont are immutable (not chnage )
// this is true only for primitive variables (integer,string,date) but not for reference values 

// when you coping an object is you really creating new variable that points to the same object

 */

//-------------------------------class 100 -----------------------------------


let lastName='Williams';
let oldLastname=lastName;
lastName='Davis';
console.log(lastName);
console.log(oldLastname);


// referenc types 
const jessica={
    firstName : 'jessica',
    lastName :'williams',
    age:27
}


const marriedJessica=jessica;// copying the object 
marriedJessica.lastName='Davis';

console.log('before marriage',jessica);
console.log('after marriage ',marriedJessica);



//marriedJessica={}// this will not work  since its a const  
// but we can chnage the value inside object property 




// another way of copying the object 



const jessica2={
    firstName : 'jessica',
    lastName :'williams',
    age:27
};


// this assign js methid is used merge the objects 
// so frist one empty{} and then object jessica2
const jessicaCopy=Object.assign({},jessica2); // this will create new object with copying all the properties from jessica2 

// here all the properties copied from one object another instead referencing the first one 


jessicaCopy.lastName='Davis'


console.log('jessica ',jessica2);
console.log('jessica copy ',jessicaCopy);

// sttil there is an issue with this , this techinque only work on the first level object 
// whch mean if an object contain another object inside , then inner object will still points to same place in memory 




const jessica3={
    firstName : 'jessica',
    lastName :'williams',
    age:27,
    family :['alice','bob']  // inner object 

};


const jessicaCopy1=Object.assign({},jessica3); // this will create new object with copying all the properties from jessica2 

// here all the properties copied from one object another instead referencing the first one 


jessicaCopy1.lastName='Davis'


console.log('jessica 3',jessica3);
console.log('jessica 3 copy ',jessicaCopy1);

console.log('----------after array manipulation  --------------');
// below manipulating copied object 
jessicaCopy1.family.push('mary');
jessicaCopy1.family.push('john');


console.log('jessica 3',jessica3);
console.log('jessica 3 copy ',jessicaCopy1);


