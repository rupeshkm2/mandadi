'use strict';

/*

// Data needed for a later exercise


// Data needed for first part of the section
const restaurant = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  order : function(starterIndex,mainIndex){
    return [this.starterMenu[starterIndex],this.mainMenu[mainIndex]];
  }

};

// assigning the array values to variables 
const arr =[2,3,4];
const a=arr[0];
const b=arr[1];
const c=arr[2];

//below is another to assning array values to multiple variable 
// de-structuring  the array 
const[x,y,z]=arr;

console.log(x,y,z);
console.log(arr);


// though we have 4 values inside categories array based on below destructuring  array declation 
// it will values accordingley , since we only declared two values (first,second) it only have two values 
const [firstVar,secondVar]=restaurant.categories;

console.log(firstVar,secondVar);


// suppose we want to assign the non sequence values from array to variable in distructuring 
// we just need to add a spce that which one we need to skip 
// here based on below we get (index 0 and index 2)

let  [firstVar1, ,secondVar1]=restaurant.categories

console.log(firstVar1,secondVar1);

// swith the values  manually 


const tempVar=firstVar1;
firstVar1=secondVar1
secondVar1=tempVar;

console.log('------after switch--------');
console.log(firstVar1,secondVar1);

// switch the value by restructring 

[firstVar1,secondVar1]=[secondVar1,firstVar1]

console.log('------after destructring switch--------');
console.log(firstVar1,secondVar1);

// element 2 from starter and element 0 from main menu 
console.log(  restaurant.order(2,0));



// destructure assignment from function 
const [starter,main]=restaurant.order(2,0);

console.log(starter,main);




// nested array destructering 

const nested =[2,4,[5,6]];

// skipping the position:1
const [i, ,j]=nested;
console.log(i,j);

// what if we want to all individual details 

const [m, ,[p,q]]=nested;
console.log(m,p,q);

// we also can set default values for the value when we are extracting 

const arrSmall=[8,9];

const [var1,var2,var3]  =arrSmall;

console.log(var1,var2,var3);// you will receive var3 as undefined as array has only two values 
// this use case useful if we dont know whow may values present inside array 

// assigning default values , here we are assigning the defailt values as 1 for all variables 
// we can assign to only variable too instead all 
const [var4=1,var5=1,var6=1]  =arrSmall;

console.log(var4,var5,var6);



//-----------------------class 104 -----------------------------

// destructuring objects 



const restaurantNew = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  openingHours: {
    thu: {
      open: 12,
      close: 22,
    },
    fri: {
      open: 11,
      close: 23,
    },
    sat: {
      open: 0, // Open 24 hours
      close: 24,
    },
  },

    order : function(starterIndex,mainIndex){
      return [this.starterMenu[starterIndex],this.mainMenu[mainIndex]];
          },

   // orderDelivery:function(obj){
   //   console.log(obj);
   // },
   // another way 
   // strring starterIndex default value to 1 
   orderDelivery:function({starterIndex=1,mainIndex,time,address}){
       console.log(`order received ${this.starterMenu[starterIndex]} and ${this.mainMenu[mainIndex]} 
       will be delivered to ${address} at ${time}`);
     },
    
};


// passing object to function parameter 
// the advantage is no need to match the order of the parameter sequence 

restaurantNew.orderDelivery({
  time:22.30,
  address :'raspberry ct',
  mainIndex:2,
  starterIndex:2,
})


// calling below with out  starterIndex
restaurantNew.orderDelivery({
  time:22.30,
  address :'raspberry ct',
  mainIndex:2
  //starterIndex:2,
})




// the one  difference here in object destruction with array destruction  we need to give variable names same as property name in object that we going to retrive 
// here we can refer any method from object , no need to use space to skip the value , sice we directley name the 
// variable name as property name , we can declare any position variable 
const {name,openingHours,categories}=restaurantNew;

console.log(name,openingHours,categories);

// what if we want the different variable names insted property names 
// propertyname: neame that we want 
const {name:NameVar,openingHours:openingHoursVar,categories:categoriesVar}=restaurantNew;
console.log(NameVar,openingHoursVar,categoriesVar);

// default values 
// assigned default empty [] , since no property menu in restaurantNew it assigned with empty 
// else we get undefined error message 
const{Menu=[],starterMenu:starterMenuVar=[]}=restaurantNew;

console.log(Menu,starterMenuVar);


// mutating variables / switch variables 

let a=111;
let b=999;

const obj={
  a:23,
  b:7,
  c:14
};

// since a and b alreasy declared above with (let )

//{a,b}=obj; // this will error our , since we add { curty brace js expert code block 


console.log(a,b);
// we just need to put inside parathasys to work 
({a,b}=obj)

console.log(a,b);

// nested objects 

const {fri}=openingHours;
console.log(fri);

// further destrucure 
const {fri:{open,close}}=openingHours;

console.log(open,close);

// giving varibale names instead property names 

const {fri:{open:avar,close:bvar}}=openingHours;

console.log(avar,bvar);



//-----------------class 105 ------------------------

// spread operator 

const arr=[7,8,9];

// add few eliments to this existing array 

const badNewArr=[1,2,arr[0],arr[1],arr[2]];

console.log(arr);
console.log(badNewArr);

// we can achive this above operation in much better way by spread operatot 
// here in spread operator we have ... to refresent all the elements in array 
const newArr=[1,2,...arr];
console.log(newArr);  
console.log(...newArr); // bring elements individually 

const restaurantNew1 = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  openingHours: {
    thu: {
      open: 12,
      close: 22,
    },
    fri: {
      open: 11,
      close: 23,
    },
    sat: {
      open: 0, // Open 24 hours
      close: 24,
    },
  },

    order : function(starterIndex,mainIndex){
      return [this.starterMenu[starterIndex],this.mainMenu[mainIndex]];
          },

          orderDelivery:function({starterIndex=1,mainIndex,time,address}){
       console.log(`order received ${this.starterMenu[starterIndex]} and ${this.mainMenu[mainIndex]} 
       will be delivered to ${address} at ${time}`);
     },
       
     orderPasta: function(ing1,ing2,ing3){
       console.log(`here is your delicious pasta with ${ing1},${ing2},${ing3}`);
     }
};




// adding new item to mainMenu at the end 
// please note here we are creating new array and not manupulating the restaurantNew1.mainmenu
const newMenu=[...restaurantNew1.mainMenu,'Gnocci'];
console.log(newMenu);

// coppy array 

const mainMenucopy=[...restaurantNew1.mainMenu];
console.log('mainMenucopy',mainMenucopy);

// join two arrays or more 


const arrayJoin =[...restaurantNew1.mainMenu,...restaurantNew1.starterMenu]
console.log(arrayJoin);


// iterables : iterables are array , strings,maps,sets but not objects 


// since string is alos a iterable we can use spread to strings 
const str='jonas';
const letters=[...str];
console.log(letters);
console.log(...letters);
//console.log(`${...str} is first name  `); // this will not work here 


const letterNew =[...str,' ' ,'.R', ,'M'];
console.log(letterNew);

const ingredients=[prompt('let\'s make pasta! ingredient 1?'),prompt('let\'s make pasta! ingredient 2?'),prompt('let\'s make pasta! ingredient 3?')];

console.log(ingredients);

//now call the function 

restaurantNew1.orderPasta(ingredients[0],ingredients[1],ingredients[2]);

// we can in this with spread operaot in much easy way 

restaurantNew1.orderPasta(...ingredients)


// from 2018 iterables alos work with objects eventhough objects are not iterable 

const restaurent ={
  name : 'chipotle',
  year :1987,
  location : 'NY'
}

const newRestaurent ={...restaurent,timeopen:9}
console.log(newRestaurent);

const newRestaurentCopy={...newRestaurent};
console.log(newRestaurentCopy);

//const exampleArr =[1,2,arr]; // please note this is not a spread 
//console.log(exampleArr);


// please note below concat and abobe spread are different 
// concat is to concat two arrays , where as spread is to add few eliments to existing arrrry
//const exampleArrNew  =[1,2]; // please note this is not a spread 
*/

/*
const exmpEr =[3,4];
const concArr=exampleArrNew.concat(exmpEr)
console.log(concArr);
*/



// ---------------------------class 106 ------------------------------

// Rest patterns and parameters 


// rest patteren is exactley smme like spread operator same syntax
// but it actiallu does the opposit of spread operaot 
// while spread is unpack the eliment in aray wheer as rest is to combilne elements into aray 

// below is spread because ... is right side of = 
const arr=[1,2,...[3,4]];
console.log(arr);


// below is rest  because ... is left side of =
// here we are creaing 3 new variable )a,b,restArray) and assigning the  values 
const [a,b,...restArry]=[1,2,3,4,5,6];

console.log(a,b,restArry);

const restaurantNew2 = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  openingHours: {
    thu: {
      open: 12,
      close: 22,
    },
    fri: {
      open: 11,
      close: 23,
    },
    sat: {
      open: 0, // Open 24 hours
      close: 24,
    },
  },

    order : function(starterIndex,mainIndex){
      return [this.starterMenu[starterIndex],this.mainMenu[mainIndex]];
          },

          orderDelivery:function({starterIndex=1,mainIndex,time,address}){
       console.log(`order received ${this.starterMenu[starterIndex]} and ${this.mainMenu[mainIndex]} 
       will be delivered to ${address} at ${time}`);
     },
       
     orderPasta: function(ing1,ing2,ing3){
       console.log(`here is your delicious pasta with ${ing1},${ing2},${ing3}`);
     },

     orderPizza : function(mainIngredient,...otherIngrediants){

        console.log(mainIngredient);
        console.log(otherIngrediants);

     }
};



const [pizza, ,risotto,...otherFood]=[...restaurantNew2.mainMenu,...restaurantNew2.starterMenu];

console.log(pizza,risotto,otherFood);

// rest element must be last element 

// below will give error  because we added variable after rest element 
// so there can be only one rest element 

//const [pizza, ,risotto,...otherFood,fries ]=[...restaurantNew2.mainMenu,...restaurantNew2.starterMenu];



// rest in objects 


const { sat,...weekDay}=restaurantNew2.openingHours;
console.log(weekDay);
console.log(sat);

// functions 

const add=function(...numbers){
//console.log(numbers);
let sum=0;
for( let i=0;i<=numbers.length-1;i++ )

  sum=sum+numbers[i];
  console.log(sum);

}


add(2,3);
add(2,3,4,5,6);
add(3,4,5,6,7,8,9);

// calling function with variable 
const x=[23,5,7];

add(...x);



restaurantNew2.orderPizza('chese','onions','olives','spinatch');


restaurantNew2.orderPizza('chese');












