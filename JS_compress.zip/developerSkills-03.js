// Remember, we're gonna use strict mode in all scripts now!
'use strict';


/*
const temparatute =[3,-2,-6,-1,'error',9,13,17,15,14,9,5]

// -what is the amplitude 
// differnece b/w heighest and lowest 

// how to compute max and min temperatures 


// - what'a sensor erro , what to do when error 
// ignore error 


// breaking up into sub programs 

// - how to ingnore errors 



const calcTempAmplitude=function(temps)
{
    let max=temps[0];
    let min=temps[0];

    for(let i=0;i<=temps.length-1;i++)
    {
        if (temps[i]==='error') // or if( typeof temps[i]==='string')
        {
            continue;
           
        }

        if(temps[i]>max)
        {
            max=temps[i];
        }

        if(temps[i]<min)
        {
            min=temps[i];
        }
    }

return max-min;
};

console.log(calcTempAmplitude(temparatute));


// function to accept two arrays as input 



// solutution , do we nned to impliment the same functionality to second array ?
// no need in the beginning we can merge the two arrays into single 


// -how to merge two arrays 
// ex : array3=array1.concat(array2);
// concat is array method 


const calcTempAmplitudetwo=function(temps1,temps2)
{
    let temps=temps1.concat(temps2);// concatinating two arrays 
    let max=temps[0];
    let min=temps[0];
    console.log(temps);
    for(let i=0;i<=temps.length-1;i++)
    {
        if (temps[i]==='error') 
        {
            continue;
        }

        if(temps[i]>max)
        {
            max=temps[i];
        }

        if(temps[i]<min)
        {
            min=temps[i];
        }
    }

return max-min;
};


console.log(calcTempAmplitudetwo([2,6,8],[5,8,9]));




//-------------------------- class 61 ------------------------------

// debugging with console and break point 


const measureKelvin=function()
{
    const measurement ={
        type:'temp',
        unit:'celcious',
        // fix is to  convert this to number 
        value:Number( prompt('Degrees celsius:'))
    }
    // find the bug 
    console.log(measurement);
    console.table(measurement);
      //debugger;  // this statement will automatically open debugger (source in crome )
        console.log(measurement.value);
      //  console.warn(measurement.value);
        //console.error(measurement.value);

        const kelvin=measurement.value+273

    return kelvin;
}

console.log(measureKelvin());



//--------------------------------class 62 ----------------------------------

// coding challenge 


const printForecast=function(tempArry)
{

    let days=1;
    let retvar='';
    for (let i=0;i<=tempArry.length-1;i++)
    {
        retvar=retvar+ `...${tempArry[i]}'C in ${days} days`;
        days=days+1;
    }

    return retvar

};

 const outvar=printForecast([12,5,-5,0,4]);

 console.log(outvar);


 */