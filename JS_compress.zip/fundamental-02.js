// Strict mode is used write code in secure way 
// to enable strict mode simply write in beginning 'use strict'
// you can impliment strict mode for specific function/block 
// it helps avoid bugs , some senarios it will highlite bugs 

/*
'use strict';
let hasDriversLicencr = false;
const passTest = true;

if (passTest) hasDriverLicencr = true; // perpously missed S is the variable name here 
// without strict mode js won't raise error , you check by commenting 'use strict'
if (hasDriversLicencr) console.log('i can drive');

const interface = 'audio';
const private = 525;
// above variables declaration is alos fail because the variable interface is reservered for futute js



// ---------------------------class 33 ----------------------------------
// functions 


//function logger(){ finction body}
// function may or may not return a values in js 
function logger() {
    console.log('my name is rupesh');

}

logger();  // calling/running/invoking  the function 


function fruitProcessor(apples, oranges) {
    console.log(apples, oranges);
    const juice = `juice with ${apples} apples  and ${oranges} oranges`;
    return juice;

}

fruitProcessor(2, 3);

const outvar = fruitProcessor(2, 3);
console.log(outvar);
// we can directley call function into console.log
console.log(fruitProcessor(5, 6));



//-------------------------------class 34 -------------------------------

// function declaration 
function calAge(birthYear) {
    const age = 2022 - birthYear;
    return age;
}

// OR 

function calAge1(birthYear) {

    return 2022 - birthYear;
}


const outCalAge = calAge(1987);
console.log(outCalAge);

// below is function excpression  , function without name 
// here age2 variable used  as  function name 

const age2 = function (birthYear) {
    return 2022 - birthYear;
}

const agevar = age2(2000);

console.log(agevar);

// the main difference is 
// we can call function declaration before the function defined for (function declaration )

// example 

// to execute below please comment out about codes 
const outCalAge = calAge(1987); // we are calling this function before function defined and it works without amy error 
function calAge1(birthYear) {

    return 2022 - birthYear;
}

console.log(outCalAge);

// where as in function expression you can't do as it will error out 
//example 

const agevar = age2(2000); // this wont work 
const age2 = function (birthYear) {
    return 2022 - birthYear;
}
console.log(agevar);



//--------------------------class 35 ----------------------------------------
// Arrow functions (=>)  , intraduces in ES6
// no need to write return statement  it it's single line function and no nned to use {}
// here birthyear is parameter  name 
//if  it it's a multiline function then we need to use {} and return statement lime other functionsn 

// example for single line arrow function 
const age3 = birthYear => 2022 - birthYear;
const age3var = age3(1987);
console.log(age3var);


// multi line arrow function 
const yearsUntillRetirement = birthYear => {
    const age = 2022 - birthYear;
    const retirement = 65 - age
    return retirement;
}

const varyesr = yearsUntillRetirement(1987);
console.log(varyesr);


// execute with mutiple parameters 


const yearsUntillRetirement1 = (birthYear, firstname) => {
    const age1 = 2022 - birthYear;
    const retirement1 = 65 - age1
    return `yesrs left for ${firstname} retirement is ${retirement1}`
}

const varyesr1 = yearsUntillRetirement1(1987, 'rupesh');
console.log(varyesr1);



// -------------------------class 36 ----------------------------

// functions calling aother functions 


function cutFruitePices(fruite) {
    return fruite * 4;
}

function fruitProcessor(apples, oranges) {
    const applePeaces = cutFruitePices(apples);// calling function 
    const orangePeaces = cutFruitePices(oranges);// calling function 
    console.log(apples, oranges, applePeaces, orangePeaces);
    const juice = `juice with ${apples} apples and ${applePeaces} peices and ${oranges} oranges ${orangePeaces} peices`;
    return juice;

}

console.log(fruitProcessor(2, 3));


//--------------------------class 37 --------------------------------------------

// review what we learned in function concept 


// ------------------class 38 coding challenge -------------


const calcAverage = (score1, score2, score3) => {
    return avgScore = (score1 + score2 + score3) / 3;
}

function doubleAvg(scoreavg) {
    return scoreavg * 2;
}

function chekWinner(avgdophind, avgkoalas) {
    if (avgdophind > doubleAvg(avgkoalas)) {
        console.log(`Dolphis win ( ${avgdophind} vs ${avgkoalas} )`)
    }
    else if (avgkoalas > doubleAvg(avgdophind)) {
        console.log(`Dolphis win ( ${avgkoalas} vs ${avgdophind} )`)
    }
    else {
        console.log('no team wins')
    }

}

const avgdophind = calcAverage(44, 23, 71);
const avgkoalas = calcAverage(65, 54, 49);

console.log(chekWinner(avgdophind, avgkoalas));

console.log(chekWinner(23, 220));



//--------------------------class 39  --------------------------------------

// arays 

const friend1 = 'mickele';
const friedn2 = 'peeter';
const friend3 = 'kevin';

// [] is an arry 
const friends = ['mickele', 'peter', 'kevin'];

console.log(friends);

// another way of declaring array
const yesrs = new Array(1991, 2000, 2001, 2002)
console.log(yesrs);
// array position start with 0 
console.log(friends[0]);
console.log(friends[2]);
// number of elements in array 
console.log(friends.length);
// get last element in array
// since it is zero based we need to use length-1 to get last element 
console.log(friends[friends.length - 1]);

// add /replace 

friends[2] = 'jay';
console.log(friends);

// eventhough we declared friends as const , still we can change the values in arrays
// this const will not work for array's
// we can't replace entire array
//friends = ['bob', 'alice'] // this will give error as assign to cont variable

const height = 6.2
// in below we passed an arry friends as an elelemt , we can calculate and pass an variable
const rupesh = ['rupesh', 'mandadi', 2022 - 1987, height, friends];
console.log(rupesh);

// example 
const calAge = function (birthYear) {
    return 2022 - birthYear;
}

const years = [1990, 1967, 2002, 2010, 2022, 2018];
// below is not an valid way to call 
calAge(years);
console.log(calAge(years));// NaN not a number 

// correct way to do
const aage1 = calAge(years[0]);
const aage2 = calAge(years[1]);
const aage3 = calAge(years[years.length - 1]);// last elelemt in array

console.log(aage1, aage2, aage3);

// we can pass function inside array 
const ages = [calAge(years[0]), calAge(years[1]), calAge(years[years.length - 1])];

console.log(ages);



//--------------------------class 40 ------------------------------
// array methods 

const friends = ['mickele', 'peter', 'kevin'];

// push method add element to end of an array 
// push methos is an function and it retuen lenghth of an array 

friends.push('jay');

//const newLength = friends.push('jay');
//console.log(newLength);

console.log(friends);


//unshift methos is used to add element in begining of an array 

friends.unshift('josh');
console.log(friends);

// pop methos remove last element 
// pop methis is and function and it return removed element

friends.pop();
//console.log(friends.pop())  
console.log(friends);


// shift methos is to remove element from beginning of an array 

friends.shift();
console.log(friends);

// indexof() will retuen the  posiion of the element
console.log(friends.indexOf('peter'));

// you will get -1 if we pass element that not exist 
console.log(friends.indexOf('test'));

// it is and ES6 and it will simply return true/false 
// if element exist then true else false 
friends.push(23);
console.log(friends.includes('peter'));
console.log(friends.includes('bob'));
console.log(friends.includes('23'));// it is false because it checks for stict value (number/string)
console.log(friends.includes(23)); // true 

//ex 
if (friends.includes('peter')) {
    console.log('you have a friemd called peter ');
}


//-------------------class 41 coding challenge -------------------------

const calcTip = function (amount) {
    if (amount >= 50 && amount <= 300) {
        return amount * 0.15;
    }
    else {
        return amount * 0.2;
    }
}


const tipamt = calcTip(300);
console.log(tipamt);

const bills = [125, 555, 44];
console.log(bills);
const tips = [calcTip(bills[0]), calcTip(bills[1]), calcTip(bills[bills.length - 1])]
console.log(tips);

const totals = [bills[0] + tips[0], bills[1] + tips[1], bills[2] + tips[2]];
console.log(totals);



//-------------------------------class 42 ------------------------------------
// objects 


const rupesharray = ['rupesh', 'mandadi', 2022 - 1987, 'developer', ['steven', 'peter', 'jay']];

// the one disadvantage of an array we cant name the element , we need to call then by position
// for example frist two element are first name and last name
// to solve this problem we have another data structure called OBJECT

// object will define with {}
// here firstName is KEY/property and 'rupesh' is an VALUE 
// below object has 5 properties 

const rupesh={
    firstName:'rupesh',
    lastName :'mandadi',
    age      :2022-1987,
    job      :'developer',
    friends  :['steven','peter','jay']

}


//-------------------------class 43 -----------------------------------


const rupesh = {
    firstName: 'rupesh',
    lastName: 'mandadi',
    age: 2022 - 1987,
    job: 'developer',
    friends: ['steven', 'peter', 'jay']

}

console.log(rupesh);

console.log(rupesh.lastName);
console.log(rupesh['age']);// if we want to compute any vlue then we can use this [] notation 

const nameKey = 'Name';
console.log(rupesh['first' + nameKey]);
console.log(rupesh['last' + nameKey]);

console.log(rupesh.friends);
console.log(rupesh.friends[0]);

const intrestedIn = prompt('what do you want to know abput rupesh choose bw firstName,lastName,age,job and friends');
console.log(intrestedIn); // enter job is pop up 
console.log(rupesh.intrestedIn);// this is undefiend as object rupesh doesn't have property called intrestedIn
console.log(rupesh[intrestedIn]); // this will work 

//ex
if (rupesh[intrestedIn]) {
    console.log(rupesh[intrestedIn]);
}
else {
    console.log(intrestedIn + ' is not an valid property')
}


// add new properties in both ways 
rupesh.location = 'USA';
rupesh['tritter'] = '@rupeshmandadi';

console.log(rupesh);




console.log(rupesh.firstName + ' has ' + rupesh.friends.length + ' friends , and his best friend is called ' + rupesh.friends[0]);



//-------------------------class 44 ---------------------------------------
//object methods 


const rupesh = {
    firstName: 'rupesh',
    lastName: 'mandadi',
    birthYar: 1987,
    job: 'developer',
    friends: ['steven', 'peter', 'jay'],
    hasDriverLicence: true,  // boolean value 
    calcAge: function (birthYar) {  // we can add function expression inside object as and property
        return 2022 - birthYar
    },

    calcAgenew: function () {   // another way to do with this clause 
        //  console.log(this);
        // we can create new poperty like below 
        this.age = 2022 - this.birthYar  // we create new property here 
        return this.age // we can refer the other properties inside object with THIS clause 
        // return 2022 - rupesh.birthYar // we can use this as well to but just to avoid repeting the same object name  rupesh multiple places 
        // just in case if we chnage the object name in future we need to chnage the all the reference points so THIS is the best way to go 
    },

    methosyno: function () { // also called as method 
        if (this.hasDriverLicence) {
            return ' a '
        }
        else {
            return ' no '
        }
    }
}

console.log(rupesh.calcAge(1987));
console.log(rupesh['calcAge'](1987)); // make sure we should pass as string with ''

console.log(rupesh.calcAge(rupesh.birthYar));

console.log(rupesh.calcAgenew());
console.log(rupesh.calcAgenew());
console.log(rupesh.calcAgenew());

// in above if we want to access age multiple time we need to call the function multiple times
// and tis is not a best way to do in terms of performance 
// instead we can do like below , access new property

console.log(rupesh.age);
console.log(rupesh.age);
console.log(rupesh.age);





console.log(`rupesh is a ${rupesh.age} - years old ${rupesh.job} 
and he has ${rupesh.methosyno(rupesh.hasDriverLicence)} driver's licence `)



//-----------------------class 45 coding challenge ------------------

const mark = {
    fullName: 'Mark Miller',
    mass: 78,
    height: 1.69,
    calBmi: function () {
        return this.mass / (this.height ** 2)
        // we can use below as well with new variable markBmi
        // this.markBmi=this.mass / (this.height ** 2)
        //return this.markBmi;
    }
}


const john = {
    fullName: 'John Smith',
    mass: 92,
    height: 1.95,
    calBmi: function () {
        return this.mass / (this.height ** 2)
    }
}

// make sure object name is case sensite 
console.log(mark.MASS); // this will not work as mass should be lower 


console.log(` ${john.fullName}'s BMI(${john.calBmi()}) is heigher then ${mark.fullName}'s BMI(${mark.calBmi()})`);



//----------------------------class 46 ---------------------------------
// loops 
// for has three parts 
// for (intial value;logical condition to evalute before each loop, increasig counter )
for (let rep = 1; rep <= 10; rep++) {
  //  console.log('lifting weights repetition ' + rep);
    //or below 
    console.log(`lifting weights repetition  ${rep}`);
}




//------------------------class 47 -----------------------------------


const rupesh = ['rupesh',
    'mandadi',
    2022 - 1987,
    'developer',
    ['steven', 'peter', 'jay']
];

const types = [];
// i=0 because array position start with zero
for (let i = 0; i < rupesh.length; i++) // for now we can ingnore second condtion in for loop 
{
    console.log(rupesh[i]);
    // populate types arry with rupesh array 
    types[i] = typeof rupesh[i];
    //types.push(typeof rupesh[i])// another way to populate 

}

console.log(types);

const years = [1991, 2007, 1969, 2020]
const ages = [];

for (let i = 0; i < years.length; i++) {
    ages.push(2022 - years[i]);
}

console.log(ages);

// continue : break the current loop and continue for next loop
// break : completely terminate whole loop
console.log('-----only stringd ----')
for (let i = 0; i < rupesh.length; i++) // for now we can ingnore second condtion in for loop 
{
    if (typeof rupesh[i] !== 'string')
        continue; // exit current iteration 
    console.log(rupesh[i]);

}

console.log('-----break with number  ----')
for (let i = 0; i < rupesh.length; i++) // for now we can ingnore second condtion in for loop 
{
    if (typeof rupesh[i] === 'number')
        break; // exit the whole  iteration 
    console.log(rupesh[i]);

}




//----------------------------class 48 --------------------------------------


const rupesh = ['rupesh',
    'mandadi',
    2022 - 1987,
    'developer',
    ['steven', 'peter', 'jay']
];



// reverse loop 

for (let i = rupesh.length - 1; i >= 0; i--) {
    console.log(rupesh[i]);
}

console.log('------------loop inside loop -----------');

// loop inside loop 

for (let excercise = 1; excercise <= 3; excercise++) {

    console.log(`----starting excercise ${excercise} `);

    for (let repetition = 1; repetition <= 5; repetition++) {
        console.log(` excersice ${excercise} lifting weight repetition ${repetition}`);

    }
}



//--------------------------class 49 ----------------------------------

// while loop

for (let repetition = 1; repetition <= 5; repetition++) {
    console.log(` lifting weight repetition ${repetition}`);

}

//conver above with  while loop
let rep = 1;
while (rep <= 5) {
    console.log(`while loop lifting weights repetion ${rep}`);
    rep++;
}

// below senario for while loop is  roll the dice untill we receive number 6 


// Math.random() this js function will return random number 
// random number always 0.nnnnnnnnn( ex: 0.235865254)

let dice = Math.trunc(Math.random() * 6) + 1
console.log(dice);


while (dice !== 6) {
    console.log(`you rolled a ${dice}`);
    dice = Math.trunc(Math.random() * 6) + 1;// added this to avoid infinite loop 
    // above  the variable dice value is re assigned and once the value 6 then it stop executing 
   
    if (dice === 6) {
        console.log('loop is about to end');
    }
}



//-------------------class 50 coding challenge -------------------------------



const calcTip = function (amount) {
    if (amount >= 50 && amount <= 300) {
        return amount * 0.15;
    }
    else {
        return amount * 0.2;
    }
};

const bills = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52];
let tips = [];
let total = [];

for (let i = 0; i <= bills.length - 1; i++) {
    tips[i] = calcTip(bills[i]);
    //tips.push(calcTip(bills[i])); //  another way to do

    total[i] = bills[i] + tips[i];
    console.log(bills[i], tips[i], total[i]);
};

// function to accespt array 
let sum = 0; // we must assign with 0 else calculation will fail with NaN error
const calcAverage = function (arr) {
    for (let i = 0; i <= arr.length - 1; i++) {
        sum = sum + arr[i];
        //sum+=arr[i]// another way 
    }
    return sum / arr.length;
};

let arrvar = calcAverage([2.6, 10]); // we can pass manually 

let arrvar1 = calcAverage(total); // we can pas an actial array name

console.log(arrvar);
console.log(arrvar1);



*/






