/*
let js = 'hello';
console.log(10 + 20 + 30);

console.log("jonas");

let firstname = 'jonas22';
console.log(firstname);
let lastName ='mandadi';
// sample single line comment

let PI =3.14 ;// if we declate veriable in caps (PI) then it shouls be
// considered and constant and the value not chnage through out program
*/

/*
multi line comments




// -------------------------- class 2 ---------------------------

true;
console.log(true);

let javascriptisfun = true;
console.log(javascriptisfun);

// typeof will give the type of the variable ex : number ,string

console.log(typeof true);
console.log(typeof 23);
console.log(typeof 'rypesh');

// dynamic typing

javascriptisfun = 'YES!'; //  assign the new value to existing variable
console.log(typeof javascriptisfun);
console.log(javascriptisfun);

//undefined
let year;
console.log(typeof year);
console.log(year);

// re assign the value

year = 2022;

console.log(typeof year);
console.log(year);

// error in type of , error/bug in javascript as it showing as objects instead null


console.log(typeof null);



//-----------calss 13 ---------------------------

let age = 30;
age = 31; // re assign the value /mutate the value

// const variable value canot be chnages

const dob = 1987;
//dob = 1988; // will give error

// you need to give value while declaring const variable else will give error
//const job; // this will give error

// var is old way of declaring , var and let are same
var job = 'programmer';
job = 'learner';

console.log(job);

// js will automaticall declare varibale though you not include var/let before variable name
// but this is not a good practice
lastname = 'mandadi';
console.log(lastname);



//----------------------------=class 14 ----------------------------------------


// operator

const agerupesh = 2022 - 1987;
const ageale = 2022 - 1995;
console.log(agerupesh, ageale);


const yearnow = 2022;
const agerupesh1 = yearnow - 1987;
const ageale1 = yearnow - 1995;
console.log(agerupesh1, ageale1);


console.log(yearnow * 2, yearnow / 2, 2 ** 3);

//2**3  menas 2 to the power of 3 : 2*2*2

// + operatot to concatinate two strings

const firname = 'rupesh';
const lasname = 'mandadi';

console.log(firname + lasname);

// if you need space between

console.log(firname + ' ' + lasname);

// assignment operator is =

let x = 10 + 5;

console.log(x);
x += 10; //  which mean x=x+10 whcich is 25
x *= 4;// whch means x= x*4 whic is 100
x++;// which mean x=x+1
x--;// which mean x=x-1
console.log(x);

// comparision operaro

console.log(2 > 1);  // return true or false (bollean)




// ---------------------------calss 15 -------------------------
// operatot precedence


console.log(20 - 2 > 12 - 10);

// developer.mozilla.org  go to precedence

let x, y;  // declare two empty vatiable

x = y = 25 - 10 - 5;
console.log(x, y);

const avgage =


//  -----------------------------coding challenge ---------------------

const marksweight = 78;
const markstall = 1.69;

const jonasweight = 92;
const jonastall = 1.95;

let calmarksbmi;
let jonasbmi


calmarksbmi = marksweight / (markstall * markstall);
console.log(calmarksbmi);

jonasbmi = jonasweight / (jonastall * jonastall);
console.log(jonasbmi)
const markhigherbmi = calmarksbmi > jonasbmi;
console.log(calmarksbmi > jonasbmi);
console.log(markhigherbmi);




//-------------------------- class 17 ------------------------------


const firstname = 'rupesh';
const job = 'developer';
const dob = 1987;
const year = 2022;
// if we need use sinle quote inside ""
const rup = "I'm" + firstname + ',a ' + (year - dob) + 'Year old ' + job;
console.log(rup);

// template literals /string
// can assemple multiple stings

const rupeshnew = `i'm ${firstname},a ${year - dob} year old ${job}`;
console.log(rupeshnew);

console.log(`i'm a developer `);// we cal always use back quotes  too

// create multi line strings

console.log('srting with \n\
multiple \n\
lines');

// simplified above one with template literal with `` (above tab key)
// we can simple entrt to go new line instead writing extra code /n/
console.log(`string
with
multiline with template string `);



// ----------------------------class 18 ------------------------

const age = 15;
//const isOldEnough = age >= 18;
//if (isOldEnough)  we can use this or below , both will work
if (age >= 18) {
    console.log('sara can start driving 👍');
}
else {
    const yesrsleft = 18 - age;
    console.log(`sara is toll young and wait another ${yesrsleft} to drive`)
}

const birthyear = 1987;
let century;
if (birthyear <= 2000) {
    century = 20;
}
else {
    century = 21;
}
console.log(century);



//---------------- calss 19 coding challenge -----------------------------

// this is the same challenge as BMI scrore , but it is with if else stmt


const marksmass = 95;
const marksheight = 1.88;
const markbmi = marksmass / (marksheight * marksheight);

const jonasmass = 85;
const jonasheight = 1.76
const jonsbmi = jonasmass / (jonasheight * jonasheight);
console.log(markbmi, jonsbmi);

if (markbmi > jonsbmi) {
    console.log(`mark's BMI (${markbmi}) is heighrt then jonas (${jonsbmi})`);
}
else {
    console.log(`jonas BMI (${jonsbmi})is heigher then marks (${markbmi}) `)
}



//----------------------- calss 20 --------------------------------

// type conversion  : explicitry we conver from one tyoe to another

// type coversion : java script automatically convert internally



// below ate type conversion
const inputyear = '1991';
console.log(Number(inputyear), inputyear);
// number is js function to convert ot number

console.log(inputyear + 10);

console.log(Number(inputyear) + 10);


console.log(Number('rupesh'));
// above will give NaN : not a number

console.log(typeof NaN);

console.log(String(23));
// string is js function to convert to string


// below are type coerction

console.log('I am ' + 23 + ' Years old');

console.log('I am ' + '23' + ' Years old');

console.log('I am ' + String(23) + ' Years old');

console.log('23' - '10' - 3);
console.log('23' - '10' + 3);
console.log('23' - '10' + '3');// carefull with + and sring


let n = '1' + 1;
n = n - 1;
console.log(n);



//---------------------class 21 ----------------------------


// 5 falsy values : 0 ,'',undefined,null,NaN

console.log(Boolean(0));
console.log(Boolean(undefined));

console.log(Boolean('jonas'));

console.log(Boolean({}));
console.log(Boolean(''));
console.log(Boolean(null));
console.log(Boolean(NaN));
// Boolean is an JS function

const money = 0;
if (money)  // Boolean(0)
{
    console.log(`don't spend ot all`);

}
else {
    console.log('you should get a job ')
}


let height;
if (height)  // (Boolean('')
{
    console.log('height is defined');

}
else {
    console.log('height is undefined');
}



let height1 = 0;
if (height1) {
    console.log('height is defined');

}
else {
    console.log('height is undefined');
}



//---------------------- class 22 ------------------------------

const age = 18;
if (age === 18)
    // equqlity  is === (strict equqlity) (no type coretion)
    //              == loose equlity (does type corection)
    // if the if condition has sinle condition we dont't need to use {}
    console.log('you just becaser an adult');

if (age == '18') //loose
    console.log('loose condition :you just becaser an adult');

if (age === '18') //strict , so failed the condition
    console.log('strict condition :you just becaser an adult');

const fave = prompt("what is your favorite number ?");
console.log(fave);

// prompt is the js function to give promt/pop
// we can store the value entered in promt by dedclarign and assign to an variable like fave
// what ever the value er enter in promt is come as string
if (fave == 2) //loose
{
    console.log('coll 2 is fantastic number');
}

if (fave === 2) // strict   and this condition fail because of fave is string
{
    console.log('strict coll 2 is fantastic number');
}

if (Number(fave) === 2)// strict
{
    console.log('strict with conversion: 2 is an fantastick number');

}

// else if


if (Number(fave) === 2)// strict
{
    console.log('strict with elsif conversion: 2 is an fantastick number');

}
else if (Number(fave) === 7) {
    console.log('entered number is 7');
}
else {
    console.log('entered number not 2 ot 7');
}

// not equal operaot

if (Number(fave) != 2) {
    console.log('why not 2')
}



//-------------------------class 23------------------------------

// AND ,OR ,NOT operators

// -----------------------class 24 -----------------------------

// logical operator

const hasDriverLicence = true;
const hasGoodVision = true;

// && is AND operator
// || OR operatot
// !  NOT operator
console.log(hasDriverLicence && hasGoodVision);
console.log(hasDriverLicence || hasGoodVision);
console.log(!hasDriverLicence);


if (hasDriverLicence && hasGoodVision) {
    console.log('sarah should able to drive');
}
else {
    console.log('someone else should drive');
}


const isTired = true;
console.log(hasDriverLicence || hasGoodVision || isTired);




if (hasDriverLicence && hasGoodVision && !isTired) {
    console.log('sarah should able to drive');
}
else {
    console.log('someone else should drive');
}




// -------------class 25 coding challenge -----------------------

const dolphavg = (96 + 108 + 89) / 3;
const koalasavg = (88 + 91 + 110) / 3;

console.log(dolphavg, koalasavg);

if (dolphavg > koalasavg) {
    console.log('The winner is Dolphins');
} else if (dolphavg === koalasavg) {
    console.log('Match is draw ');
}
else {
    console.log('The winner is Koalas');
}


//------------------------class 26 -----------------------------------

// switch statement : alternative to if else statement

const day = 'monday';
switch (day) {
    case 'monday':  // day==='monday'
        console.log('Plan course structure');
        console.log('go to coding meetup');
    //  break; // if you not add break, code simpley continue executing next blocks
    case 'tuesday':
        console.log('prepare theory videos');
        break;
    case 'wednesday':
    case 'thursday':
        console.log('code examples ');
        break;
    case 'friday':
        console.log('record videos');
        break;
    case 'saturday':
    case 'sunday':
        console.log('enjoy weekend ');
        break;
    default: // like an else block
        console.log('Nota a valid day');

}

// same example with if else statement

const day1 = 'monday';

if (day1 === 'monday') {
    console.log('Plan course structure');

}
else if (day1 === 'tuesday') {
    console.log('prepare theory videos');
}
else if (day1 === 'wednesday' || day1 === 'thursday') {
    console.log('code examples');

}
else if (day1 === 'friday') {
    console.log('record videos');
}
else if (day1 === 'saturday' || day1 === 'sunday') {
    console.log('enjoy weekend');
}
else {
    console.log('not a valid day ');
}





//-------------------------class 27 ------------------------------------

// statements and expressions

// 3+4 is an expression ( it does produce an value )
// 1991 is an expression
// true , false , && !false is an expression
// statement means which doesn't produce value , translate as action

if (23 > 10) {
    const str = '23 is is bigger'; // this is an statement
}

console.log(`i'm ${2022 - 1987} years old`);
// ${2022 - 1987} is an expression




//------------------------- class 28 ---------------------------

// conditional operator

const age = 21;
age >= 18 ? console.log('i like to drink cofee') :
    console.log('i like to drink water')


// in this  : is works like an else stmt
// ? -> which acts  like  THEN , if age >=18 then
// ? ->    Please note only one ststment is allowed after ?


const drink = age >= 18 ? ' drink cofee' : 'drink water';
console.log(drink);

// another way

let drink2;
if (age >= 18) {
    drink2 = 'cofee';
}
else {
    drink2 = 'water';
}

console.log(drink2);

console.log(`i like to drink ${age >= 18 ? ' drink cofee' : 'drink water'}`)



//----------------------class 29 coding challenge ----------------------

const billAmt = 275;
let tipAmt;

billAmt >= 50 && billAmt <= 300 ? tipAmt = billAmt * 0.15 :
    tipAmt = billAmt * 0.2

console.log(`the bill value is ${billAmt} so the tip amount is ${tipAmt}`);


*/

//--------------------------class 30 ------------------------------------

// ES5,ES6+ AND ESNEXT

// -----------------------CLASS 31  INTO-------------------------

//---------------------------CLASS 31 --------------------------------
































